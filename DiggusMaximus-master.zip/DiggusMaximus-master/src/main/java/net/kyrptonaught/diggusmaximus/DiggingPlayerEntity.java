package net.kyrptonaught.diggusmaximus;

public interface DiggingPlayerEntity {
    Boolean isExcavating();

    void setExcavating(boolean isExcavating);
}
