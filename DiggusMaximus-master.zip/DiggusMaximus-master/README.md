# Diggus Maximus
Dig more better!

https://www.curseforge.com/minecraft/mc-mods/diggus-maximus