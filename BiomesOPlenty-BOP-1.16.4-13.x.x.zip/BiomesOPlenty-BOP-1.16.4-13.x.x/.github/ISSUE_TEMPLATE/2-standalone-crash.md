---
name: 1.16.3 Standalone Crash
about: For crashes that occur with Biomes O' Plenty for 1.16.3.  We do not support older versions!
title: ''
labels: crash
assignees: ''

---

## Bug Report

[ Lines between [ ] (square brackets) should be removed before posting. ]</br>

### How can the crash be reproduced?

[ Include a detailed step by step process for recreating your crash with only Biomes O' Plenty installed. ]</br>

### Crash Report and Logs

[ Please include your crash report and logs here. This can be done by dragging and dropping your log files and crash report files into the issue. ]</br>

### Mod Version
[ Please put the version of the mod you were using here. ]</br>
