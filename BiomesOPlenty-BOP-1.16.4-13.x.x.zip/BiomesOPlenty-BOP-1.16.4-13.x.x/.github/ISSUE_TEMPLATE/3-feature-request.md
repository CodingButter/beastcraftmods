---
name: 1.16.3 Feature Request
about: Feature requests for Biomes O' Plenty for 1.16.3.  We do not support older versions!
title: ''
labels: feature
assignees: ''

---

## Feature Request

[ Lines between [ ] (square brackets) should be removed before posting. ]</br>

### What feature are you suggesting?

[ Provide an overview of the feature being suggested. ]</br>

### Why should it be added?

[ Describe the benefits of implementing this feature. ]</br>
