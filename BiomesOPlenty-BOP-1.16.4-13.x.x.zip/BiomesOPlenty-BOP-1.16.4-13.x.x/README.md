<p align="center"><img src="https://i.imgur.com/HQ2opH6.png"></p>

<p align="center"><img src="https://i.imgur.com/CYxKg5M.png"></p>

<p align="center">https://discord.gg/GyyzU6T</p>

**Biomes O' Plenty** is a **Minecraft mod** that adds **over 50 new biomes** to the Overworld, Nether, and End. From Lavender Fields to Redwood Forests and many more, all of our biomes are decorated with a variety of **new trees, flowers, and plants!**

-----------------

**Note:** To use the mod on a **server**, you must set the **level-type** setting in your server's config file to **biomesoplenty**

-----------------

 [<img src="http://i.creativecommons.org/l/by-nc-nd/3.0/88x31.png">](http://creativecommons.org/licenses/by-nc-nd/4.0/deed.en_US)

Biomes O' Plenty is licensed under a [Creative Commons Attribution-NonCommercial-NoDerivs 4.0 Unported License](http://creativecommons.org/licenses/by-nc-nd/4.0/deed.en_US).