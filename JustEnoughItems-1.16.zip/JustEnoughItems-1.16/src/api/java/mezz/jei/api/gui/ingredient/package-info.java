@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.gui.ingredient;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.api.MethodsReturnNonnullByDefault;
