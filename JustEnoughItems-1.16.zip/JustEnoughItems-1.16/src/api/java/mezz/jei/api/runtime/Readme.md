# JEI Runtime

The runtime package of the API offers access to JEI's runtime features, like the GUIs that draw on the screen.
From here you can control the filter text, open the recipe gui, get items displayed in JEI under the mouse, etc.