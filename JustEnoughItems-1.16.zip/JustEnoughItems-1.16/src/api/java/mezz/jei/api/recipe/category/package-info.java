@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.category;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.api.MethodsReturnNonnullByDefault;
