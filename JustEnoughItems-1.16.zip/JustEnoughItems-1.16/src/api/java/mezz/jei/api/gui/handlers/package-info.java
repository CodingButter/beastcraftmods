@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.gui.handlers;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.api.MethodsReturnNonnullByDefault;
