# JEI Registration

The classes in this package are for setting up your JEI plugin.  
Instances of these registration classes are passed in to your `IModPlugin`'s register methods.