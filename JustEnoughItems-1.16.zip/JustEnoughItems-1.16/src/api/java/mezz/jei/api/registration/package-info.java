@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.registration;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.api.MethodsReturnNonnullByDefault;
