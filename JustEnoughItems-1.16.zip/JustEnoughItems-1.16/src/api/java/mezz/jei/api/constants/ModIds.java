package mezz.jei.api.constants;

public class ModIds {
	public static final String JEI_ID = "jei";
	public static final String JEI_NAME = "Just Enough Items";

	public static final String MINECRAFT_ID = "minecraft";
	public static final String MINECRAFT_NAME = "Minecraft";
}
