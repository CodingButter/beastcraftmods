package mezz.jei.api.recipe.vanilla;

public interface IJeiBrewingRecipe {
	int getBrewingSteps();
}
