@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.constants;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.api.MethodsReturnNonnullByDefault;
