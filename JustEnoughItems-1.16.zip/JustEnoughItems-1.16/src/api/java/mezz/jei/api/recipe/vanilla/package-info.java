@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api.recipe.vanilla;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.api.MethodsReturnNonnullByDefault;
