@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package mezz.jei.api;

import javax.annotation.ParametersAreNonnullByDefault;
