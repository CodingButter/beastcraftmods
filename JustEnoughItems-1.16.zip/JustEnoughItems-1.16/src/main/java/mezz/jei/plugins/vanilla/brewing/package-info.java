@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.plugins.vanilla.brewing;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.util.FieldsAndMethodsAreNonnullByDefault;
