@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.plugins.vanilla.crafting;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.util.FieldsAndMethodsAreNonnullByDefault;
