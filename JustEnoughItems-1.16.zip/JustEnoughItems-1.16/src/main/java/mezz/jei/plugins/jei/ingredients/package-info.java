@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.plugins.jei.ingredients;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.util.FieldsAndMethodsAreNonnullByDefault;
