package mezz.jei.gui.recipes;

@FunctionalInterface
public interface IOnClickHandler {
	void onClick(double mouseX, double mouseY);
}
