@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.gui.recipes;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.util.FieldsAndMethodsAreNonnullByDefault;
