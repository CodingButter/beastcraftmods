package mezz.jei.network;

public enum PacketIdClient implements IPacketId {
	CHEAT_PERMISSION;

	public static final PacketIdClient[] VALUES = values();
}
