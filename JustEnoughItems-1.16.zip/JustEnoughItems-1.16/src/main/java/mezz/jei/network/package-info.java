@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.network;

import javax.annotation.ParametersAreNonnullByDefault;

import mezz.jei.util.FieldsAndMethodsAreNonnullByDefault;
