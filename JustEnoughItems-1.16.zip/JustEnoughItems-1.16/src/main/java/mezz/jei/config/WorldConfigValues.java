package mezz.jei.config;

public class WorldConfigValues {
	public boolean overlayEnabled = true;
	public boolean cheatItemsEnabled = false;
	public boolean editModeEnabled = false;
	public boolean bookmarkOverlayEnabled = true;
	public String filterText = "";
}
