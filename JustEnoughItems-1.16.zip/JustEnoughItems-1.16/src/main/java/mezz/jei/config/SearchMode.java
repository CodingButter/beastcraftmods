package mezz.jei.config;

public enum SearchMode {
	ENABLED, REQUIRE_PREFIX, DISABLED
}
