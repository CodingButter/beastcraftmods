package mezz.jei.config;

public interface IFilterTextSource {
	String getFilterText();
}
