@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.config.sorting;

import mezz.jei.util.FieldsAndMethodsAreNonnullByDefault;

import javax.annotation.ParametersAreNonnullByDefault;
