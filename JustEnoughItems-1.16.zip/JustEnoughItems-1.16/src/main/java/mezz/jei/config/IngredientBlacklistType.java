package mezz.jei.config;

public enum IngredientBlacklistType {
	ITEM, WILDCARD;

	public static final IngredientBlacklistType[] VALUES = values();
}
