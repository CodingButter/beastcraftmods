package mezz.jei.ingredients;

public enum IngredientSortStage {
	MOD_NAME, INGREDIENT_TYPE, ALPHABETICAL, CREATIVE_MENU
}
