package mezz.jei.events;

import net.minecraftforge.eventbus.api.Event;

public class JeiEvent extends Event {
}
