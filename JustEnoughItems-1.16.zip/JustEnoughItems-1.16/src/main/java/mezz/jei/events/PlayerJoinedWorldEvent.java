package mezz.jei.events;

public class PlayerJoinedWorldEvent extends JeiEvent {
}
