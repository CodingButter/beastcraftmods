@ParametersAreNonnullByDefault
@FieldsAndMethodsAreNonnullByDefault
package mezz.jei.util;

import javax.annotation.ParametersAreNonnullByDefault;
