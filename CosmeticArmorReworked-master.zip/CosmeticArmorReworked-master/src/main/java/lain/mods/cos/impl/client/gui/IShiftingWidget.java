package lain.mods.cos.impl.client.gui;

public interface IShiftingWidget {

    void shiftLeft(int diffLeft);

}
