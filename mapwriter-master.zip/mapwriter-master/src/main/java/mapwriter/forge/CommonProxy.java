package mapwriter.forge;

import java.io.File;

public class CommonProxy {
	public void preInit(File configFile) {}
	public void load() {}
	public void postInit() {}
}
